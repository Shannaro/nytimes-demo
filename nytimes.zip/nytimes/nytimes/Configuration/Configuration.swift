//
//  Configuration.swift
//  nytimes
//
//  Created by Shantanu Khanwalkar on 07/07/18.
//  Copyright © 2018 Shantanu Khanwalkar. All rights reserved.
//

import Foundation

struct API {
    
    static let APIKey = "api-key=7d263fa0d9784d488ceca8bec410cf7e"
    static let BaseURL = "http://api.nytimes.com/svc/mostpopular/v2/mostviewed/"
    
}

struct CellNames {
    static let articleCell = "ArticleTableViewCell"
}
